﻿using UnityEngine;
using System.Collections;

public class Score : MonoBehaviour {
	public static long totalM;
	public static bool ScrollFlag = true;
	public static int goldenKishimen = 0;
	public static int ancientKishimen = 0;
	public static int normalKishimen = 0;

	public static int goldenEbifurai = 0;
	public static int ancientEbifurai = 0;
	public static int normalEbifurai = 0;

	public static int goldenMisokatsu = 0;
	public static int ancientMisokatsu = 0;
	public static int normalMisokatsu = 0;

	public static int goldenTebasaki = 0;
	public static int ancientTebasaki = 0;
	public static int normalTebasaki = 0;

	public static int IeyasuArmor = 0;
	public static int IeyasuSword = 0;
	public static int IeyasuKabuto = 0;
}

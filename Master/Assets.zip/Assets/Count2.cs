﻿using UnityEngine;
using System.Collections;

public class Count2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.normalTebasaki++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

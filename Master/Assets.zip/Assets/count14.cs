﻿using UnityEngine;
using System.Collections;

public class count14 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.IeyasuArmor++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

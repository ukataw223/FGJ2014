﻿using UnityEngine;
using System.Collections;

public class count9 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.goldenKishimen++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

﻿using UnityEngine;
using System.Collections;

public class count10 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.ancientTebasaki++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

﻿using UnityEngine;
using System.Collections;

public class Count : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.normalEbifurai++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

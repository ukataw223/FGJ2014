﻿using UnityEngine;
using System.Collections;

public class Count6 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.ancientMisokatsu++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour {
	public static int gage = 100;
	public static float Global_timer = 0;
	public static int ComboCount = 0;

}

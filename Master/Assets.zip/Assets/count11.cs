﻿using UnityEngine;
using System.Collections;

public class count11 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.goldenTebasaki++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

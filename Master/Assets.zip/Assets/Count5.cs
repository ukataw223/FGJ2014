﻿using UnityEngine;
using System.Collections;

public class Count5 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Score.ancientEbifurai++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
